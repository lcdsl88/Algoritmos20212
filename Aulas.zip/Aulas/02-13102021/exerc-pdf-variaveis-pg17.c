# include <stdio.h>

int main(){
 int x,y;
 double z;
 x=2;
// y=x+y;
// z=x/y;
 printf("x = %d\n",x);
 printf("y = %d\n",y);
 printf("z = %lf\n",z);
 return(0);
}
