#include <iostream>
using namespace std;

void Insere(int V[], int N, int x, int p); 
// V-> Vetor; N -> Numero de elementos; x-> elemento a ser inserido; p-> posição do elemento

int main(){
	//lista linear
	//não-ordenada
	//sequencial
	int V[11];
	int N = 0;
	Insere(V,0,3,1); // Considerei o numero N = 0 de elementos inicial do vetor 
	//Insere(V,1,4,2); // Agora considerei o vetor com N = 1 elemento
	//Insere(V,2,5,1); // Por fim com N = 2 elementos
	cout << V[1]; // SAIDA: 3
	//cout << V[1] << V[2]; // SAIDA: 34
	//cout << V[1] << V[2] << V[3]; // SAIDA: 543
	return 0;
}

void Insere(int V[], int N, int x, int p){
	V[N+1]=V[p];
	V[p]=x;
	N=N+1;
}