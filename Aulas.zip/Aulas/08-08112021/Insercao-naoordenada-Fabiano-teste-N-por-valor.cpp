#include <iostream>
using namespace std;

void Insere(int V[], int N, int x, int p){
	V[N+1] = V[p];
	V[p] = x;
	N = N+1;
}

int main(){
	//lista linear
	//não-ordenada
	//sequencial
	
	int V[11];
	int N = 0;
	
	Insere(V,N,3,1);
	cout << N;
}